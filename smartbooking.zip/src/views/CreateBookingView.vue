<!-- src/views/CreateBookingView.vue -->
<template>
  <div class="container-fluid min-vh-100 bg-light py-4">
    <!-- Header Block -->
    <div class="row justify-content-center mb-4">
      <div class="col-xl-10 col-12 d-flex justify-content-between align-items-center">
        <div>
          <h4 class="fw-bold mb-1 text-dark">ສົ່ງຄຳຂໍຈອງລົດບໍລິສັດ</h4>
          <p class="text-muted small mb-0">{{ currentCompany }}</p>
        </div>
        <button @click="goBack" class="btn btn-outline-secondary">
          <i class="bi bi-arrow-left me-1"></i> ກັບໄປໜ້າຫຼັກ
        </button>
      </div>
    </div>

    <!-- Main Workspace Layout -->
    <div class="row justify-content-center">
      <div class="col-xl-10 col-12">
        <div class="row g-4">
          
          <!-- Left Side: Data Fields Entry -->
          <div class="col-lg-7 col-12">
            <div class="card border-0 shadow-sm p-4 bg-white rounded-3">
              <h5 class="fw-bold mb-3 border-bottom pb-2 text-secondary">ຕື່ມຂໍ້ມູນການເດີນທາງ</h5>
              
              <div class="mb-3">
                <label class="form-label fw-semibold text-muted small">ຈຸດປະສົງການເດີນທາງ *</label>
                <input type="text" v-model="form.description" class="form-control form-control-lg" placeholder="ເຊັ່ນ ໄປຮັບແຂກຜູ້ສະໜອງ" required />
              </div>

              <div class="row mb-3 g-3">
                <div class="col-md-6 col-12">
                  <label class="form-label fw-semibold text-muted small">ວັນເວລາເລີ່ມຕົ້ນ *</label>
                  <input ref="startInput" type="text" v-model="form.start" class="form-control" required />
                </div>
                <div class="col-md-6 col-12">
                  <label class="form-label fw-semibold text-muted small">ວັນເວລາສິ້ນສຸດ *</label>
                  <input ref="stopInput" type="text" v-model="form.stop" class="form-control" required />
                </div>
              </div>

              <div class="mb-3">
                <label class="form-label fw-semibold text-muted small">ຈຳນວນຜູ້ດຳເນີນ *</label>
                <input type="number" v-model="form.number_of_participant" class="form-control" min="1" placeholder="3 ຄົນ (ລວມຜູ້ຂັບຂີ່)" required />
              </div>

              <div class="mb-3">
                <label class="form-label fw-semibold text-muted small">ເບີໂທຕິດຕໍ່ *</label>
                <input type="tel" v-model="form.tel" class="form-control" placeholder="ເບີໂທຕິດຕໍ່" required />
              </div>
              <div class="mb-4">
                <label class="form-label fw-semibold text-muted small">
                  ຕ້ອງການເອົາຄົນຂັບຄົນບໍ່?
                </label>

                <div class="form-check form-switch">
                  <input
                    id="keepDriver"
                    v-model="form.keep_driver"
                    class="form-check-input"
                    type="checkbox"
                    role="switch"
                  />

                  <label class="form-check-label" for="keepDriver">
                    {{ form.keep_driver ? 'ໃຊ້ຄົນຂັບ' : 'ບໍ່ເອົາຄົນ' }}
                  </label>
                </div>
              </div>

              <div class="mb-4">
                <label class="form-label fw-semibold text-muted small">ໝາຍເຫດເພີ່ມເຕີມ</label>
                <textarea v-model="form.description" class="form-control" rows="3" placeholder="ລາຍລະອຽດຕ່າງໆ "></textarea>
              </div>

              <!-- Available Vehicles Display List -->
              <h6 class="fw-bold text-dark mb-3">ລົດທີ່ວ່າງໃຫ້ຈອງ</h6>
              <div v-if="vehiclesLoading" class="text-muted py-3" role="status">
                <span class="spinner-border spinner-border-sm me-2"></span>
                กำลังโหลดรายการรถ...
              </div>
              <div v-else-if="vehiclesError" class="alert alert-danger mb-2" role="alert">
                {{ vehiclesError }}
              </div>
              <div v-else-if="availableVehicles.length === 0" class="alert alert-info mb-2">
                ບໍ່ມີລົດວ່າງໃຫ້ຈອງ
              </div>
              <button
                v-for="vehicle in availableVehicles"
                :key="vehicle.id"
                type="button"
                class="card w-100 text-start mb-2 p-3"
                :class="selectedVehicleId === vehicle.id ? 'border-primary bg-light' : 'border-light'"
                :aria-pressed="selectedVehicleId === vehicle.id"
                @click="selectVehicle(vehicle)"
              >
                <div class="d-flex align-items-center justify-content-between">
                  <div class="d-flex align-items-center">
                    <i class="bi bi-car-front-fill fs-2 me-3 text-primary"></i>
                    <div>
                      <strong class="text-dark d-block">{{ vehicle.brand }}{{ vehicle.name }} {{ vehicle.sign }}</strong>
                      <span class="text-muted small d-block">{{ vehicle.capacity }} ບ່ອນນັ່ງ</span>
                    </div>
                  </div>
                  <span
                    class="badge p-2"
                    :class="selectedVehicleId === vehicle.id ? 'bg-primary' : 'bg-success-subtle text-success border border-success'"
                  >
                    {{ selectedVehicleId === vehicle.id ? 'ເລືອກແລ້ວ' : 'ວ່າງ' }}
                  </span>
                </div>
              </button>
            </div>
          </div>

          <!-- Right Side: Finalization Column -->
          <div class="col-lg-5 col-12">
            <div class="card border-primary border-2 p-4 bg-white shadow-sm rounded-3 d-flex flex-column">
              <h5 class="text-primary fw-bold mb-4">ສະຫຼູບຂໍ້ມູນຄຳຂໍຈອງລົດ</h5>
              
              <div class="d-flex justify-content-between mb-3 border-bottom pb-2">
                <span class="text-muted">ປະເພດເດີນທາງ</span>
                <span class="fw-bold text-dark text-end ms-3">
                  {{ selectedVehicle ? ` (${selectedVehicle.capacity} ບ່ອນນັ່ງ)` : 'ຍັງບໍ່ໄດ້ເລືອກລົດ' }}
                </span>
              </div>
              <div class="d-flex justify-content-between mb-3 border-bottom pb-2">
                <span class="text-muted">ໄລຍະເວລາລວມ</span>
                <span class="fw-bold text-success fs-5">{{ durationTime }} ຊົ່ວໂມງ</span>
              </div> 

              <button @click="submitBooking" type="button" class="btn btn-primary btn-lg w-100 py-3 mt-auto fw-bold" :disabled="submitting">
                <span v-if="submitting" class="spinner-border spinner-border-sm me-2"></span>
                ສົ່ງຄຳຂໍຈອງ
              </button>
            </div>
          </div>

        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onBeforeUnmount, onMounted } from "vue";
import { useRouter } from "vue-router";
import { getAvailableCars, createBookingEvent } from "../api/axios";
import flatpickr from "flatpickr";
import "flatpickr/dist/flatpickr.min.css";
  


const router = useRouter(); 
const currentCompany = ref("บจก. ไทยโซลูชั่นส์ ลอจิสติกส์");
const submitting = ref(false);
const startInput = ref(null);
const stopInput = ref(null);
const datePickers = [];
const availableVehicles = ref([]);
const vehiclesLoading = ref(false);
const vehiclesError = ref("");
const selectedVehicleId = ref(null);
const selectedVehicle = computed(() =>
  availableVehicles.value.find((vehicle) => vehicle.id === selectedVehicleId.value)
);
 
const formatToDateTimeLocal = (dateInput) => {
  if (!dateInput) return ''
  const date = new Date(dateInput)
  const tzOffset = date.getTimezoneOffset() * 60000 // offset in milliseconds
  const localISOTime = (new Date(date.getTime() - tzOffset)).toISOString().slice(0, 16)
  return localISOTime
} 
const form = ref({
  booking_id: null,
start: formatToDateTimeLocal(new Date()), 
  stop: formatToDateTimeLocal(new Date(Date.now() + 2 * 60 * 60 * 1000)), // +2 hours
  description: "",
  number_of_participant: null,
  tel: "", 
  keep_driver: false,
});
const durationTime = computed(() => {
  if (!form.value.start || !form.value.stop) return 0;
  
  const startObj = new Date(form.value.start);
  const stopObj = new Date(form.value.stop);
  const differenceInMs = stopObj - startObj;
  
  // Returns hours rounded to 1 decimal place (e.g., 2.5), or 0 if stop is before start
  return differenceInMs > 0 
    ? parseFloat((differenceInMs / (1000 * 60 * 60)).toFixed(1)) 
    : 0;
});
const calculateDuration = () => {
  if (form.value.start && form.value.stop) {
    const startObj = new Date(form.value.start);
    const stopObj = new Date(form.value.stop);
    const differenceInMs = stopObj - startObj;
    form.value.duration_time = differenceInMs > 0 ? parseFloat((differenceInMs / (1000 * 60 * 60)).toFixed(1)) : 0;
  }
};

const loadAvailableVehicles = async () => {
  vehiclesLoading.value = true;
  vehiclesError.value = "";
  try {
    const result = await getAvailableCars();
    if (!result?.status || !Array.isArray(result.data)) {
      throw new Error(result?.message || "Unable to load vehicles");
    }
    availableVehicles.value = result.data;
    if (!availableVehicles.value.some((vehicle) => vehicle.id === selectedVehicleId.value)) {
      selectedVehicleId.value = null;
      form.value.booking_id = null;
    }
  } catch (error) {
    console.error("Failed to load available vehicles:", error);
    vehiclesError.value = "ບໍ່ສາມາດໂຫຼດລາຍການລົດໄດ້";
  } finally {
    vehiclesLoading.value = false;
  }
};

const selectVehicle = (vehicle) => {
  selectedVehicleId.value = vehicle.id;
  form.value.booking_id = vehicle.id;
};

const goBack = () => {
  router.push({ name: 'Dashboard' }); // Fallback navigation back to main layout dashboard
};

const submitBooking = async () => {
  if (!form.value.description || !form.value.start || !form.value.stop || !form.value.number_of_participant || !form.value.tel) {
    alert("กรุณากรอกข้อมูลที่จำเป็น (*) ให้ครบถ้วน");
    return;
  }
  submitting.value = true;
  try {
    const payload = {
      booking_id: selectedVehicleId.value,
      start: form.value.start.replace("T", " ") + ":00",
      stop: form.value.stop.replace("T", " ") + ":00",
      description: form.value.description, 
        confirmed_state: selectedVehicleId.value ? "waiting_for_approval" : "draft",
      number_of_participant: Number(form.value.number_of_participant),
      tel: form.value.tel.trim(),
  duration_time: durationTime.value ,
  keep_driver: form.value.keep_driver,
    };
    const response = await createBookingEvent(payload);
    
    if (response.data) {
      alert("ส่งคำขอจองรถยนต์เรียบร้อยแล้ว!");
      goBack();
    } else {
      alert("เกิดข้อผิดพลาด: " + (response.data.message || "Unknown error"));
    }
  } catch (err) {
    console.error(err);
    const message = err.response?.data?.message || err.response?.data?.error ||
      (err.response ? `HTTP ${err.response.status}` : "No response from server");
    alert(`ສົ່ງຄຳຂໍບໍ່ສຳເລັດ: ${message}`);
  } finally {
    submitting.value = false;
  }
};
onMounted(() => {
 currentCompany.value = localStorage.getItem("company_name") || "";
 loadAvailableVehicles();
 const datePickerOptions = {
   enableTime: true,
   time_24hr: true,
   dateFormat: "Y-m-d\\TH:i",
   altInput: true,
   altFormat: "d/m/Y H:i"
 };

 datePickers.push(
   flatpickr(startInput.value, {
     ...datePickerOptions,
     onChange: (_, dateString) => {
       form.value.start = dateString;
       calculateDuration();
     }
   }),
   flatpickr(stopInput.value, {
     ...datePickerOptions,
     onChange: (_, dateString) => {
       form.value.stop = dateString;
       calculateDuration();
     }
   })
 );
})

onBeforeUnmount(() => {
 datePickers.forEach((datePicker) => datePicker.destroy());
})
</script>
