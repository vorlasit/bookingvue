<template>
    <div class="dashboard-admin animate-fade-in">
        <!-- 1. KPI TOP SUMMARY CARDS -->
        <div class="row g-3 mb-4">
            <!-- Total Vehicles -->
            <div class="col-12 col-sm-6 col-xl-3">
                <div class="kpi-card shadow-sm">
                    <div class="kpi-body">
                        <span class="text-muted small d-block mb-1">ລົດທັງໝົດໃນລະບົບ</span>
                        <div class="d-flex align-items-baseline gap-2">
                            <span class="fs-2 fw-bold text-dark">{{
                summary.total_vehicles
              }}</span>
                            <span class="text-muted small">ຄັນ</span>
                        </div>
                    </div>
                    <div class="kpi-icon icon-blue">
                        <i class="bi bi-car-front"></i>
                    </div>
                </div>
            </div>

            <!-- Ready to Use -->
            <div class="col-12 col-sm-6 col-xl-3">
                <div class="kpi-card shadow-sm">
                    <div class="kpi-body">
                        <span class="text-muted small d-block mb-1">ພ້ອມໃຊ້ງານ</span>
                        <div class="d-flex align-items-baseline gap-2">
                            <span class="fs-2 fw-bold text-dark">{{
                summary.available_vehicles
              }}</span>
                            <span class="text-muted small">ຄັນ</span>
                        </div>
                    </div>
                    <div class="kpi-icon icon-green">
                        <i class="bi bi-check-circle"></i>
                    </div>
                </div>
            </div>

            <!-- Active Trips -->
            <div class="col-12 col-sm-6 col-xl-3">
                <div class="kpi-card shadow-sm">
                    <div class="kpi-body">
                        <span class="text-muted small d-block mb-1">ກຳລັງໃຊ້ງານ</span>
                        <div class="d-flex align-items-baseline gap-2">
                            <span class="fs-2 fw-bold text-dark">{{ summary.on_trip }}</span>
                            <span class="text-muted small">ຄັນ</span>
                        </div>
                    </div>
                    <div class="kpi-icon icon-orange">
                        <i class="bi bi-cursor"></i>
                    </div>
                </div>
            </div>

            <!-- Maintenance -->
            <div class="col-12 col-sm-6 col-xl-3">
                <div class="kpi-card shadow-sm">
                    <div class="kpi-body">
                        <span class="text-muted small d-block mb-1">ຢູ່ລະຫວ່າງສ້ອມແປງ</span>
                        <div class="d-flex align-items-baseline gap-2">
                            <span class="fs-2 fw-bold text-dark">{{
                summary.maintenance
              }}</span>
                            <span class="text-muted small">ຄັນ</span>
                        </div>
                    </div>
                    <div class="kpi-icon icon-red">
                        <i class="bi bi-wrench"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- 2. SPLIT LAYOUT: CRITICAL ALERTS & PENDING RETURNS -->
        <div class="row g-4">
            <!-- LEFT HAND SIDE: ALERTS & TODAY'S TRIPS -->
            <div class="col-12 col-lg-7">
                <!-- Critical Alerts Block -->
                <div class="card border-0 shadow-sm p-4 mb-4 dashboard-block">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5 class="fw-bold m-0 section-title">
                            ລາຍການແຈ້ງປັນຫາ (Critical Alerts)
                        </h5>
                    </div> 
                    <div v-for="problem in problem_results" :key="problem.booking_id" class="alert-item mb-3 border shadow-sm" @click="openAlert(problem.booking_id)">
                        <div class="fw-bold d-flex align-items-center gap-2"> 
                            {{ problem.booking_id }}
                            {{ problem.driver }}
                        </div>

                        <small class="text-muted">
                            {{ problem.booking_number || "" }}
                        </small>

                          <div v-for="prob in problem.problems" :key="prob.problem_id" class="d-flex align-items-center gap-2 ps-3 mb-1">
                            <!-- Optional: Display the problem image if it exists -->
                            <img v-if="prob.image" :src="prob.image" class="rounded" style="width: 30px; height: 30px; object-fit: cover;" />
                            
                            <p class="mb-0 text-secondary small text-wrap" style="white-space: pre-line;">
                                • {{ prob.name || "" }}
                            </p>
                        </div>
                    </div>

                    <!-- Alert Item 2 -->
                    <div class="alert-item alert-warning">
                        <div class="d-flex justify-content-between align-items-start mb-1 row">
                            ການສົ່ງລົດລ່າຊ້າກວ່າເວລາທີ່ກຳນົດ

                            <div v-for="alert in alerts" :key="alert.id" class="alert-item mb-3" :class="
                  alert.level === 'critical'
                    ? 'alert-critical'
                    : 'alert-warning'
                " @click="openAlert(alert.id)">
                                <div class="fw-bold d-flex align-items-center gap-2" :class="
                    alert.level === 'critical' ? 'text-danger' : 'text-warning'
                  ">
                                    <i class="bi" :class="
                      alert.level === 'critical'
                        ? 'bi-exclamation-triangle-fill'
                        : 'bi-exclamation-circle-fill'
                    "></i>

                                    {{ alert.title }}
                                </div>

                                <small class="text-muted">
                                    {{ alert.time_ago || "" }}
                                </small>

                                <p class="mb-0 text-secondary small ps-4 text-wrap" style="white-space: pre-line;">
                                    <div v-for="(line, index) in alert.message.split('\n')" :key="index">
                                        {{ line }}
                                    </div>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Employee Trips Timeline Block -->
                <div class="card border-0 shadow-sm p-4 dashboard-block">
                    <h5 class="fw-bold mb-4 section-title">ການເດີນທາງຂອງມື້ນີ້</h5>

                    <div class="trip-timeline" v-for="trip in todayTrips" :key="trip.id"  @click="openAlert(trip.id)">
                        <div class="trip-item border-bottom pb-3 mb-3">
                            <h5>{{ trip.name }}</h5>

                            <div>
                                👤 {{ trip.employee }}
                            </div>

                            <div>
                                🚗 {{ trip.vehicle_name }}
                                ({{ trip.vehicle_plate }})
                            </div>

                            <div>
                                🕐 {{ trip.start }} -
                                {{ trip.stop }}
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- RIGHT HAND SIDE: PENDING APPROVALS / RETURNS -->
            <div class="col-12 col-lg-5">
                <div class="card border-0 shadow-sm p-4 dashboard-block ">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h5 class="fw-bold m-0 section-title">ຄຳຂອງຄືນລົດ</h5>
                        <span class="badge bg-primary-light text-primary px-2 py-1 small rounded">{{ returnRequests.length }} รายการ</span>
                    </div>
 
                    <div class="request-inner-card border rounded p-3" v-for="request in returnRequests" :key="request.id" @click="openAlert(request.id)">
                        <div class="d-flex justify-content-between align-items-start mb-2">
                           <div >
                                <div class="fw-bold text-dark">{{ request.employee }}  </div> 
                            </div>
                            <span class="badge bg-info-light text-info rounded-pill px-2 py-1 small">ລໍຖ້າຮັບລົດຄືນ</span>
                        </div>

                        <div class="text-secondary small mb-3">
                            <div class="mb-1">
                                <i class="bi bi-calendar3 me-2"></i> ວັນທີ່ເດີນທາງ: {{ request.start }}
                            </div>
                            <div class="mb-1">
                                <i class="bi bi-car-front me-2"></i>  ລົດທີ່ໃຊ້: {{ request.vehicle_name }} ({{ request.vehicle_plate }})
                            </div>
                            <div>
                                <i class="bi bi-people me-2"></i> ຄົນຂັບ: {{ request.driver || "ບໍ່ມີຄົນຂັບ" }}
                            </div>
                        </div>
 
                        <div class="col-12"> 
                            <button
                                type="button"
                                class="btn btn-primary w-100"
                                @click="receiveBookingCarAction"
                                :disabled="receivingCar"
                            >
                                <span
                                v-if="receivingCar"
                                class="spinner-border spinner-border-sm me-1"
                                ></span>

                                <i v-else class="bi bi-check-circle me-1"></i>

                                {{ receivingCar ? "ກຳລັງຮັບລົດຄືນ..." : "ຮັບລົດຄືນ" }}
                            </button>
                        </div>  
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script setup>
    import {
        ref,
        onMounted
    } from "vue";
    import {
        getBookingDashboard,
        receiveBookingCar,
        getEventDetail
    } from "../api/axios";
    import router from "../router";
    const loading = ref(true);
    const summary = ref({
        total_vehicles: 0,
        available_vehicles: 0,
        on_trip: 0, 
        maintenance: 0,
    });
    const alerts = ref([]);
    const todayTrips = ref([]);
    const returnRequests = ref([]);
    const problem_results = ref([]);
    const openAlert = (alert) => { 
        console.log("CLICK ALERT:", alert); 
        if (!alert) {
            console.warn("No id:", alert);
            return;
        } 
        router.push(`/booking/history${alert}`);
    };
    
const receiveBookingCarAction = async () => {
  if (!booking.value?.id) {
    alert("ບໍ່ພົບ Booking ID");
    return;
  }

  // Must be returned before admin can receive the car
  if (booking.value.state !== "returned") {
    alert("ລົດຄັນນີ້ຍັງບໍ່ໄດ້ສົ່ງຄືນ");
    return;
  }

  receivingCar.value = true;

  try {
    const response = await receiveBookingCar(booking.value.id);

    console.log("RECEIVE CAR RESPONSE:", response);

    if (response?.status) {
      alert("ຮັບລົດຄືນສຳເລັດ");

      await fetchBookingDetail();
    } else {
      alert(response?.message || "ບໍ່ສາມາດຮັບລົດຄືນໄດ້");
    }
  } catch (error) {
    console.error("Receive car error:", error);

    alert(error.response?.data?.message || "ລະບົບຂັດຂ້ອງ ບໍ່ສາມາດຮັບລົດຄືນໄດ້");
  } finally {
    receivingCar.value = false;
  }
};
const fetchBookingDetail = async () => {
  loading.value = true;
  errorMessage.value = "";
  try {
    const bookingId = route.params.id;
    const response = await getEventDetail(bookingId);
    // Unpack data smoothly checking structure variants
    console.log("FETCH BOOKING DETAIL RESPONSE:", response);
    if (response && response.status) {
      booking.value = response.data;
    } else if (response && response.id) {
      booking.value = response;
    } else {
      errorMessage.value = "ไม่สามารถโหลดข้อมูลการจองนี้ได้.";
    }
  } catch (error) {
    console.error(error);
    errorMessage.value =
      error.response?.data?.message || "เกิดข้อผิดพลาดในการเชื่อมต่อระบบ.";
  } finally {
    loading.value = false;
  }
};
    const loadDashboard = async () => {
        try {
            loading.value = true;
            const result = await getBookingDashboard();
            if (result) {
                summary.value = result.summary;
                alerts.value = result.alerts || [];
                todayTrips.value = result.today_trips || [];
                returnRequests.value = result.return_requests || [];
                problem_results.value = result.problem_results || [];
            } else {
                console.error(result.message);
                return;
            }
        } catch (error) {
            console.error("Failed to load dashboard:", error);
        } finally {
            loading.value = false;
        }
    };
    onMounted(() => {
        loadDashboard();
    });
</script>

<style scoped>
    /* ==========================================================================
   COMPONENT CUSTOM STYLING (MATCHING THE ORIGINAL UI CAPTURE)
   ========================================================================== */

    .dashboard-admin {
        font-family:
            -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue",
            Arial, sans-serif;
        color: #333333;
    }

    .section-title {
        font-size: 16px;
        color: #2c2c2c;
    }

    /* --- KPI Summary Card Styles --- */
    .kpi-card {
        background: #ffffff;
        border-radius: 12px;
        padding: 20px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        border: 1px solid #f0f0f2;
    }

    .kpi-icon {
        width: 44px;
        height: 44px;
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 20px;
    }

    .icon-blue {
        background-color: #ebf3ff;
        color: #1e74fd;
    }

    .icon-green {
        background-color: #e6f9f0;
        color: #10b981;
    }

    .icon-orange {
        background-color: #fff4eb;
        color: #f59e0b;
    }

    .icon-red {
        background-color: #fdf2f2;
        color: #ef4444;
    }

    /* --- Dashboard Blocks Layout --- */
    .dashboard-block {
        border-radius: 14px;
        background-color: #ffffff;
    }

    /* --- Alert Styling Tones --- */
    .alert-item {
        padding: 14px 16px;
        border-radius: 8px;
        font-size: 14px;
    }

    .alert-critical {
        background-color: #fff5f5;
        border-left: 4px solid #ef4444;
    }

    .alert-warning {
        background-color: #fffbeb;
        border-left: 4px solid #f59e0b;
    }

    /* --- Custom Bootstrap Badge Shading Overrides --- /
.bg-danger-light  { background-color: #fee2e2; }
.bg-warning-light { background-color: #fef3c7; }
.bg-primary-light { background-color: #f3e8ee; } / Shaded closer to primary #714B67 */
    .bg-info-light {
        background-color: #e0f2fe;
    }

    /* --- Sub Card Design (Right Column) --- */
    .request-inner-card {
        background-color: #ffffff;
        border-color: #eaeaea !important;
        transition:
            transform 0.2s,
            box-shadow 0.2s;
    }

    .request-inner-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.04);
    }

    .btn-primary {
        background-color: #2563eb !important;
        border-color: #2563eb !important;
    }

    .btn-primary:hover {
        background-color: #1d4ed8 !important;
    }

    .btn-light {
        background-color: #f8fafc;
    }

    /* --- Simple Animations --- */
    .animate-fade-in {
        animation: fadeIn 0.3s ease-in-out;
    }

    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(10px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
</style>