<!-- src/views/StartTripView.vue -->
<template>
  <div class="container-fluid min-vh-100 bg-light py-4">
    <!-- Top Step Navigation Header Bar -->
    <div class="row justify-content-center mb-3">
      <div class="col-xl-9 col-12 d-flex justify-content-between align-items-center">
        <div>
          <h4 class="fw-bold mb-1 text-dark">ຂໍ້ມູນການໃຊ້ງານທຮິບ</h4>
          <p class="text-muted small mb-0">ທຮິບ: {{ booking?.description || 'กำลังโหลด...' }}</p>
        </div>
        <span class="text-success fw-bold small"><i class="bi bi-circle-fill fs-8 me-1"></i> พร้อมเริ่มทริป</span>
      </div>
    </div>

    <!-- Step Information Breadcrumb Ribbon Indicator -->
    <div class="row justify-content-center mb-4">
      <div class="col-xl-9 col-12 d-flex justify-content-between align-items-center border-bottom pb-2">
        <span class="text-primary fw-bold small">ຂັ້ນຕອນທີ 1: ການເລີ່ມໃຊ້ງານທຮິບ</span>
        <span class="text-muted small">ຂັ້ນທີ 1 ຈາກ 2</span>
      </div>
    </div>

    <!-- Core Submission Workspace Layout -->
    <div class="row justify-content-center">
      <div class="col-xl-9 col-12">
        <form @submit.prevent="handleStartTripSubmit" class="card border-0 shadow-sm p-4 bg-white rounded-3">
          
          <!-- Section 1: Driver Profile Selector Group -->
          <div class="mb-4">
            <h6 class="fw-bold text-dark mb-1">ຂໍ້ມູນການໃຊ້ງານທຮິບ</h6>
            <label class="form-label fw-semibold text-muted small mb-2">ผู้ขับรถจริงสำหรับทริปนี้</label>
            
            <!-- Pseudo Dropdown Field Container Layout Block matching Image -->
            <div class="d-flex align-items-center justify-content-between p-3 border rounded-3 bg-white cursor-pointer">
              <div class="d-flex align-items-center">
                <!-- Driver Dummy Avatar Frame -->
                <div class="bg-light rounded-circle d-flex align-items-center justify-content-center me-3" style="width: 42px; height: 42px; overflow: hidden;">
                  <i class="bi bi-person-fill text-secondary fs-4"></i>
                </div>
                <div>
                  <strong class="text-dark d-block fs-6">{{ booking?.driver || 'อนุชา ไชยดี' }}</strong> 
                </div>
              </div>
              <i class="bi bi-chevron-down text-muted"></i>
            </div>
            <span class="text-muted text-xxs d-block mt-2">ผู้ขับจริงอาจเป็นคนละคนกับผู้จองได้ หากต้องการเปลี่ยนให้เลือกจากพนักงานในบริษัท</span>
          </div>

          <!-- Section 2: Numerical Input for Mileage Counter Tracker -->
          <div class="mb-4">
            <label class="form-label fw-semibold text-dark mb-1">เลขไมล์ก่อนใช้งาน (กิโลเมตร) *</label>
            <input 
              type="number" 
              v-model="startForm.mile_before" 
              class="form-control form-control-lg bg-white border"
              placeholder="กรอกเลขไมล์ เช่น 145280"
              required
            />
            <span class="text-muted text-xxs d-block mt-2">
              * เลขไมล์ล่าสุดของรถก่อนเริ่มทริปคือ {{ booking?.latest_mile || '142,500' }} กม.
            </span>
          </div>

          <!-- Section 3: Graphic Photo Base64 Uploader Box Element Layout -->
          <div class="mb-4">
            <label class="form-label fw-semibold text-dark mb-1">ภาพถ่ายหน้าปัดก่อนใช้งาน *</label>
            
            <!-- Clickable Interactive Photo Upload Trigger Anchor Workspace Box -->
            <div 
              @click="triggerFileSelect"
              class="border border-dashed rounded-3 p-5 text-center bg-light cursor-pointer position-relative d-flex flex-column align-items-center justify-content-center"
              style="border-style: dashed !important; min-height: 180px;"
            >
              <!-- Show dynamic preview placeholder if file is selected successfully -->
              <template v-if="!startForm.image_mile_before">
                <i class="bi bi-camera-fill text-muted fs-1 mb-2"></i>
                <span class="text-muted small">แตะเพื่อเปิดกล้องถ่ายภาพหน้าปัดรถยนต์</span>
              </template>
              <template v-else>
                <img :src="`data:image/png;base64,${startForm.image_mile_before}`" class="img-fluid rounded shadow-sm" style="max-height: 160px;" />
                <span class="badge bg-dark position-absolute bottom-0 mb-2">แตะเพื่อเปลี่ยนรูป</span>
              </template>
              
              <!-- Hidden Native Input Element Box Target -->
              <input ref="fileInput" type="file" accept="image/*" capture="environment" class="d-none" @change="handlePhotoCapture" />
            </div>
          </div>

          <!-- Actions Submission Button Frame Footer Layout -->
          <button 
            type="submit" 
            class="btn btn-success btn-lg w-100 py-3 fw-bold mt-2" 
            :disabled="submitting || !startForm.mile_before || !startForm.image_mile_before"
          >
            <span v-if="submitting" class="spinner-border spinner-border-sm me-2"></span>
            บันทึกและเริ่มทริป <i class="bi bi-arrow-right ms-1"></i>
          </button>

        </form>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from "vue";
import { useRoute, useRouter } from "vue-router";
import { getEventDetail, startBookingTripAPI } from "../api/axios";

const route = useRoute();
const router = useRouter();

const fileInput = ref(null);
const booking = ref(null);
const loading = ref(true);
const submitting = ref(false);
const errorMessage = ref("");

const startForm = ref({
  booking_id: route.params.id,
  mile_before: null,
  image_mile_before: ""
});

const fetchBookingContext = async () => {
  try {
    const response = await getEventDetail(route.params.id);
    if (response && response.status) {
      booking.value = response.data;
    }
  } catch (err) {
    errorMessage.value = "ไม่สามารถดึงข้อมูลทริปได้";
  } finally {
    loading.value = false;
  }
};

const triggerFileSelect = () => {
  fileInput.value.click();
};

// Converts the captured dashboard camera element picture into a clean Base64 string for Odoo
const handlePhotoCapture = (event) => {
  const file = event.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onloadend = () => {
    // Strips out headers metadata from Base64 string chunk logic array elements
    const base64String = reader.result.split(',')[1];
    startForm.value.image_mile_before = base64String;
  };
  reader.readAsDataURL(file);
};

const handleStartTripSubmit = async () => {
  submitting.value = true;
  try {
    const res = await startBookingTripAPI(startForm.value);
    if (res.status) {
      alert("เริ่มต้นทริปสำเร็จ รถกำลังเดินทาง!");
      router.push(`/booking/history${startForm.value.booking_id}`);
    } else {
      alert(res.message || "เกิดข้อผิดพลาด");
    }
  } catch (error) {
    console.error(error);
    alert("ระบบขัดข้อง ไม่สามารถบันทึกข้อมูลการเริ่มทริปได้");
  } finally {
    submitting.value = false;
  }
};

onMounted(() => {
  fetchBookingContext();
});
</script>

<style scoped>
.text-xxs {
  font-size: 0.76rem;
}
.cursor-pointer {
  cursor: pointer;
}
.border-dashed {
  border: 2px dashed #dee2e6 !important;
}
</style>
