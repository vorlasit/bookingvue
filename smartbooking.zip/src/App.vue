<script setup> 
</script>

<template>    
<router-view /> 
</template>
<style scoped> 
@font-face {
  font-family: "Noto Sans Lao";
  src: url("./font/NotoSansLao-VariableFont_wdth,wght.ttf") format("truetype");
  font-weight: 700;
}
* {
    font-family: "Noto Sans Lao", "Noto Sans", sans-serif;
}
</style>
