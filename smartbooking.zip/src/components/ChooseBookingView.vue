
<template>
  <div class="choose-page">
    <div class="container">
      <div class="text-center mb-5">
        <h2 class="fw-bold">Welcome to SmartBooking</h2>
        <p class="text-muted">
          Please choose the service you want to use
        </p>
      </div>

      <div class="row justify-content-center g-4">
        <!-- Room Booking -->
        <div class="col-12 col-md-5">
          <div class="service-card room-card"
               @click="chooseService('room')">
            <div class="service-icon room-icon">
              <i class="bi bi-building"></i>
            </div>

            <h4>Room Booking</h4>
            <p>Book meeting rooms and manage room reservations.</p>

            <button class="btn btn-primary w-100">
              Enter Room Dashboard
              <i class="bi bi-arrow-right ms-2"></i>
            </button>
          </div>
        </div>

        <!-- Car Booking -->
        <div class="col-12 col-md-5">
          <div class="service-card car-card"
               @click="chooseService('car')">
            <div class="service-icon car-icon">
              <i class="bi bi-car-front-fill"></i>
            </div>

            <h4>Car Booking</h4>
            <p>Book vehicles and manage your trips.</p>

            <button class="btn btn-success w-100">
              Enter Car Dashboard
              <i class="bi bi-arrow-right ms-2"></i>
            </button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { useRouter } from 'vue-router'

const router = useRouter()

const chooseService = (type) => {
  localStorage.setItem('booking_type', type)

  router.push({
    path: '/app/dashboard',
    query: { type }
  })
}
</script>

<style scoped>
.choose-page {
  min-height: 100vh;
  display: flex;
  align-items: center;
  padding: 50px 0;
  background: #f5f7fb;
}

.service-card {
  height: 100%;
  min-height: 300px;
  padding: 35px 28px;
  background: #fff;
  border: 1px solid #e9edf3;
  border-radius: 20px;
  box-shadow: 0 8px 30px rgba(0, 0, 0, 0.05);
  cursor: pointer;
  transition: transform 0.2s, box-shadow 0.2s;
}

.service-card:hover {
  transform: translateY(-6px);
  box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
}

.service-card h4 {
  margin: 20px 0 10px;
  font-weight: 700;
}

.service-card p {
  min-height: 48px;
  color: #6c757d;
}

.service-icon {
  width: 75px;
  height: 75px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 18px;
  font-size: 36px;
}

.room-icon {
  color: #0d6efd;
  background: #e8f1ff;
}

.car-icon {
  color: #198754;
  background: #e5f7ed;
}
</style>
